extinction.times <-
function(tree){
	times <- age.tips(tree)
	times
	}


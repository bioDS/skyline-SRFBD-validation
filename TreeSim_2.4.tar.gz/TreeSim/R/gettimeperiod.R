gettimeperiod <-
function(numbs,n){
	timeperiods <- which(numbs[,3]==n)
	timeperiods
	}


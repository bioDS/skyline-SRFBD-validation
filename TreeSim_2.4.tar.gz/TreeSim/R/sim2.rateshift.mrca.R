sim2.rateshift.mrca <- function(age, numbsim, lambda, mu, times, norm = TRUE) {
    cat("dead end TODO\n")
}
